#!/bin/bash
# Test the API from Cloud Shell, before the website exists.
# Pretend to be a different user with AS=<name>, e.g.:  AS=bob bash api.sh list
#
#   bash api.sh create <name>     new server (MC_VERSION=26.3 or ONLINE_MODE=true to change defaults)
#   bash api.sh list              your servers and their ids
#   bash api.sh start <id>        start it (or join the queue if all slots are busy)
#   bash api.sh status <id>       status, address, players, queue position
#   bash api.sh watch <id>        status every 10 s (Ctrl+C to quit)
#   bash api.sh stop <id>         save, back up, power off (or leave the queue)
#   bash api.sh delete <id>       delete the server and its world for good
#   bash api.sh reconcile         run the cleanup + queue job now instead of waiting 2 min
#   bash api.sh logs              the API's recent log lines (handy when something fails)
#
# The pretend-user commands only work in test mode (AUTH_MODE=test bash setup.sh).
# In Phase 4 mode, use the website instead; reconcile and logs still work.
set -euo pipefail
URL=$(gcloud run services describe mc-api --region=asia-south1 --format='value(status.url)' 2>/dev/null || true)
if [ -z "$URL" ]; then echo "API not deployed yet. Run: bash setup.sh"; exit 1; fi
TOKEN=$(gcloud auth print-identity-token)
AS=${AS:-me}

call() {  # call METHOD PATH [JSON]
  local args=(-sS -X "$1" "$URL$2" -H "Authorization: Bearer $TOKEN" -H "X-Test-User: $AS")
  if [ -n "${3:-}" ]; then args+=(-H "Content-Type: application/json" -d "$3"); fi
  local out; out=$(curl "${args[@]}")
  if [ -n "$out" ]; then echo "$out" | jq . 2>/dev/null || echo "$out"; fi
  if echo "$out" | grep -q 'Please log in'; then
    echo "(The API is in website mode now, so pretend users are switched off. Use the website,"
    echo " or go back to test mode with: AUTH_MODE=test bash setup.sh)"
  fi
}
need_id() {
  if [ -z "${2:-}" ]; then echo "Usage: bash api.sh $1 <server-id>   (ids: bash api.sh list)"; exit 1; fi
}

case "${1:-}" in
  create)
    if [ -z "${2:-}" ]; then echo "Usage: bash api.sh create <name>"; exit 1; fi
    call POST /servers "{\"name\":\"$2\",\"version\":\"${MC_VERSION:-1.21.4}\",\"onlineMode\":${ONLINE_MODE:-false}}" ;;
  list)      call GET /servers ;;
  status)    need_id "$@"; call GET "/servers/$2" ;;
  watch)     need_id "$@"; while true; do clear; date; call GET "/servers/$2"; sleep 10; done ;;
  start)     need_id "$@"; call POST "/servers/$2/start" ;;
  stop)      need_id "$@"; call POST "/servers/$2/stop" ;;
  delete)    need_id "$@"; call DELETE "/servers/$2"; echo "Deleted (unless an error is shown above)." ;;
  reconcile) gcloud scheduler jobs run mc-reconcile --location=asia-south1
             echo "Reconcile triggered. See what it did in ~20 s with: bash api.sh logs" ;;
  logs)      gcloud run services logs read mc-api --region=asia-south1 --limit=40 ;;
  *)         sed -n '2,16p' "$0" ;;
esac
