// Spawnpoint dashboard. Signs in with Google (Firebase Auth) and talks to our API
// on the same Cloud Run service. Every API call carries the user's Firebase ID token.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.0.0/firebase-app.js';
import {
  getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut,
} from 'https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js';
import { firebaseConfig } from './firebase-config.js';

const MAX_PER_USER = 2;
const MOVING = ['queued', 'starting', 'stopping'];
const $ = (id) => document.getElementById(id);
let auth = null;
let refreshTimer = null;
let lastHtml = '';

function show(section) {
  for (const id of ['loading', 'not-configured', 'signed-out', 'signed-in']) $(id).hidden = id !== section;
}

async function api(method, path, body) {
  const token = await auth.currentUser.getIdToken();
  const res = await fetch(path, {
    method,
    headers: { Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || `The server answered ${res.status}. Try again in a moment.`);
  return data;
}

// ---------------------------------------------------------------- text
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
function ago(iso) {
  const min = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (min < 2) return 'just now';
  if (min < 60) return `${plural(min, 'minute')} ago`;
  const h = Math.round(min / 60);
  if (h < 36) return `${plural(h, 'hour')} ago`;
  return `${plural(Math.round(h / 24), 'day')} ago`;
}

function describe(s) {
  switch (s.status) {
    case 'offline':
      return ['Off', s.lastBackupAt ? `Your world was saved ${ago(s.lastBackupAt)}.` : 'Press Start to create your world.'];
    case 'queued':
      return ['Waiting for a free slot', `You're number ${s.queuePosition || 1} in line. It starts by itself when a slot opens up.`];
    case 'starting':
      return ['Starting', 'Setting up the machine and loading your world. This takes 3 to 5 minutes.'];
    case 'online': {
      const p = s.players || { online: 0, max: 10 };
      return ['Online', `${p.online} of ${p.max} playing. It switches off 10 minutes after the last player leaves.`];
    }
    case 'stopping':
      return ['Saving', 'Saving your world and switching off. This takes about a minute.'];
    case 'error':
      return ['Needs attention', s.error || 'Something went wrong with this server.'];
    default:
      return [s.status, ''];
  }
}

function actions(s) {
  switch (s.status) {
    case 'offline':
      return '<button class="block-btn" data-act="start" type="button">Start</button>'
        + '<button class="link danger" data-act="delete" type="button">Delete server</button>';
    case 'queued':
      return '<button class="block-btn quiet" data-act="stop" type="button">Leave the queue</button>';
    case 'starting':
    case 'online':
      return '<button class="block-btn stop" data-act="stop" type="button">Stop</button>';
    case 'stopping':
      return '<button class="block-btn" type="button" disabled>Saving…</button>';
    case 'error':
      return '<button class="link danger" data-act="delete" type="button">Delete server</button>';
    default:
      return '';
  }
}

function serverHtml(s) {
  const [title, text] = describe(s);
  const address = s.status === 'online' && s.address
    ? `<div class="address"><code>${esc(s.address)}</code>
         <button class="link" data-act="copy" data-copy="${esc(s.address)}" type="button">Copy address</button></div>
       <p class="how">In Minecraft: Multiplayer, Add Server, then paste the address.</p>`
    : '';
  const launcher = s.onlineMode ? 'Official Microsoft accounts only.' : 'Any launcher can join.';
  return `<article class="server" data-status="${esc(s.status)}" data-id="${esc(s.id)}" aria-live="polite">
    <div class="block" aria-hidden="true"></div>
    <div class="info">
      <h3>${esc(s.name)}</h3>
      <p class="state"><strong>${esc(title)}.</strong> ${esc(text)}</p>
      ${address}
      <p class="meta">Minecraft ${esc(s.version)}. ${launcher}</p>
    </div>
    <div class="actions">${actions(s)}</div>
    <p class="form-error panel-error" role="alert"></p>
  </article>`;
}

function render(servers, cap) {
  const html = servers.length
    ? servers.map(serverHtml).join('')
    : '<p class="empty">You don\'t have a server yet. Create one below, then press Start.</p>';
  if (html !== lastHtml) { // only redraw when something changed, so keyboard focus isn't lost
    $('servers').innerHTML = html;
    lastHtml = html;
  }
  $('capacity').textContent = `${cap.running} of ${plural(cap.max, 'server')} running${cap.waiting ? `, ${cap.waiting} waiting` : ''}`;
  $('create').hidden = servers.length >= MAX_PER_USER;
}

// ---------------------------------------------------------------- data
async function load() {
  clearTimeout(refreshTimer);
  try {
    const [servers, cap] = await Promise.all([api('GET', '/servers'), api('GET', '/capacity')]);
    $('list-error').textContent = '';
    render(servers, cap);
    schedule(servers.some((s) => MOVING.includes(s.status)) ? 5000 : 30000);
  } catch (e) {
    $('list-error').textContent = e.message;
    schedule(15000);
  }
}
function schedule(ms) {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => (document.hidden ? schedule(ms) : load()), ms);
}
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && auth?.currentUser) load();
});

$('servers').addEventListener('click', async (ev) => {
  const btn = ev.target.closest('button[data-act]');
  if (!btn) return;
  const panel = btn.closest('.server');
  const id = panel.dataset.id;
  const name = panel.querySelector('h3').textContent;
  const err = panel.querySelector('.panel-error');
  const act = btn.dataset.act;

  if (act === 'copy') {
    await navigator.clipboard.writeText(btn.dataset.copy);
    btn.textContent = 'Copied';
    setTimeout(() => { btn.textContent = 'Copy address'; }, 2000);
    return;
  }
  if (act === 'delete' && !confirm(`Delete "${name}" and its world for good? This can't be undone.`)) return;

  btn.disabled = true;
  err.textContent = '';
  try {
    if (act === 'start') await api('POST', `/servers/${id}/start`);
    if (act === 'stop') await api('POST', `/servers/${id}/stop`);
    if (act === 'delete') await api('DELETE', `/servers/${id}`);
    lastHtml = '';
    await load();
  } catch (e) {
    err.textContent = e.message;
    btn.disabled = false;
  }
});

$('create').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = ev.target;
  const btn = f.querySelector('button[type="submit"]');
  const name = f.elements.name.value.trim().toLowerCase();
  $('create-error').textContent = '';
  if (!/^[a-z][a-z0-9-]{1,18}[a-z0-9]$/.test(name)) {
    $('create-error').textContent = 'Use 3 to 20 lowercase letters, digits or hyphens, starting with a letter.';
    f.elements.name.focus();
    return;
  }
  btn.disabled = true;
  try {
    await api('POST', '/servers', {
      name,
      version: f.elements.version.value,
      onlineMode: !f.elements.anyLauncher.checked,
    });
    f.reset();
    await load();
  } catch (e) {
    $('create-error').textContent = e.message;
  } finally {
    btn.disabled = false;
  }
});

// ---------------------------------------------------------------- sign in
function signInMessage(e) {
  if (e.code === 'auth/unauthorized-domain') {
    return "This site's address isn't on Firebase's allowed list yet. Run setup.sh again, or add it under Authentication, Settings, Authorized domains.";
  }
  if (e.code === 'auth/popup-blocked') return 'Your browser blocked the sign-in window. Allow pop-ups for this site and try again.';
  return `Sign-in didn't work: ${e.message}`;
}

if (!firebaseConfig) {
  show('not-configured');
} else {
  auth = getAuth(initializeApp(firebaseConfig));
  onAuthStateChanged(auth, (user) => {
    if (user) {
      $('who-email').textContent = user.email || '';
      $('who').hidden = false;
      show('signed-in');
      lastHtml = '';
      load();
    } else {
      $('who').hidden = true;
      clearTimeout(refreshTimer);
      show('signed-out');
    }
  });
  $('signin').addEventListener('click', async () => {
    $('signin-error').textContent = '';
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (e) {
      if (e.code !== 'auth/popup-closed-by-user' && e.code !== 'auth/cancelled-popup-request') {
        $('signin-error').textContent = signInMessage(e);
      }
    }
  });
  $('signout').addEventListener('click', () => signOut(auth));
}
