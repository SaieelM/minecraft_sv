// setup.sh fills this in from your Firebase web app. These values are public by design:
// they only identify the project. Security comes from the API checking every token.
export const firebaseConfig = null;
