# mc-api: the Spawnpoint website + backend (Cloud Run + Firestore + Firebase Auth)

One Cloud Run service serves both the dashboard website (`public/`) and the API
that creates and stops the game VMs. Firestore holds who owns which server, the
max-5 slots and the queue. Firebase Authentication handles "Sign in with Google".

## Files

| File | What it is |
|---|---|
| `public/` | The website: `index.html`, `style.css`, `app.js`, `firebase-config.js` (filled in by setup) |
| `index.js` | The API: login check, servers, slots and queue, reconcile job |
| `gcp.js` | Talks to Compute Engine (VMs) and Cloud Storage (backups) |
| `startup.sh` | Runs on every game VM boot: restore, play, back up, power off |
| `firestore.rules` | Blocks browsers from the database; only the API may use it |
| `setup.sh` | Setup and redeploy (run again after any code change) |
| `api.sh` | Command-line testing (pretend users in test mode, plus `reconcile` and `logs`) |

## Phase 4: one-time Firebase setup (in your browser)

1. **Add Firebase to your project.** Go to console.firebase.google.com, start creating a
   project, and choose the option to add Firebase to an existing Google Cloud project.
   Pick your project (e.g. `samaan-new1`), turn Google Analytics off, and finish.
2. **Turn on Google sign-in.** In the left menu: Build > Authentication > Get started >
   Sign-in method > Google > Enable. Choose your email as the support email. Save.
3. **Register the website.** Project Overview > Add app > Web (the `</>` icon).
   Nickname: `spawnpoint`. Leave Firebase Hosting unticked. Register app, then
   Continue to console. You don't need to copy the config; `setup.sh` reads it.

Then in Cloud Shell, inside this folder:

```
bash setup.sh
```

It prints your website address at the end. Open it and sign in.

## Test mode (Phase 3)

```
AUTH_MODE=test bash setup.sh       # private API, no website login
bash api.sh create steve           # note the "id"
bash api.sh start <id>
AS=bob bash api.sh create bobworld # AS= picks a pretend user
```

## If something goes wrong

- **"Access blocked" or "restricted to users within its organization" when friends sign in:**
  Google Cloud console > Google Auth Platform > Audience. Set the user type to External
  and publish the app. College and company Google accounts often start as Internal.
- **"This site's address isn't on Firebase's allowed list":** Firebase console >
  Authentication > Settings > Authorized domains > add your `...run.app` address.
- **Anything else:** `bash api.sh logs` shows the API's recent log lines.

## How it decides things

- **Who owns what:** `servers/{id}.ownerUid` is the Firebase user ID. The VM is `mc-<id>`,
  the world is `gs://BUCKET/<id>/world.tgz`.
- **Max servers running:** `meta/slots` in Firestore, changed only inside transactions.
- **Queue:** when all slots are busy, Start puts the server in `meta/slots.queue`.
  The reconcile job (every 2 min) starts the oldest queued server when a slot frees up.
- **Never losing a world:** a VM is deleted only if its backup is newer than its last start.
  Otherwise it is kept and the server shows "Needs attention".
- **Who may call reconcile:** only Cloud Scheduler's Google-signed token for `mc-scheduler`.
