// Everything that talks to Compute Engine (VMs) and Cloud Storage (backups).
const fs = require('fs');
const path = require('path');
const compute = require('@google-cloud/compute');
const { Storage } = require('@google-cloud/storage');

const { PROJECT, ZONE, BUCKET } = process.env;
const VM_SA = `mc-game-vm@${PROJECT}.iam.gserviceaccount.com`;
const MACHINE = 'e2-standard-2'; // 2 vCPU, 8 GB
const STARTUP = fs.readFileSync(path.join(__dirname, 'startup.sh'), 'utf8');

const instances = new compute.InstancesClient();
const zoneOps = new compute.ZoneOperationsClient();
const bucket = new Storage().bucket(BUCKET);

const vmName = (id) => `mc-${id}`;
const isNotFound = (e) => e && (e.code === 404 || e.code === 5 || /not ?found/i.test(e.message || ''));

// Compute calls return an operation; wait until it's DONE and fail loudly if it errored.
async function waitOp(resp) {
  let op = resp.latestResponse;
  while (op.status !== 'DONE') {
    [op] = await zoneOps.wait({ operation: op.name, project: PROJECT, zone: ZONE });
  }
  if (op.error && op.error.errors && op.error.errors.length) {
    throw new Error(op.error.errors.map((e) => e.message).join('; '));
  }
  return op;
}

// Website settings -> itzg/minecraft-server environment variables (one per line).
function envFile(config) {
  return [
    'EULA=TRUE',
    'TYPE=PAPER',
    `VERSION=${config.version}`,
    `ONLINE_MODE=${config.onlineMode ? 'TRUE' : 'FALSE'}`,
    'MEMORY=6G',
    `MOTD=${config.motd || 'Hosted on Google Cloud'}`,
    'ENABLE_AUTOSTOP=TRUE',
    'AUTOSTOP_TIMEOUT_EST=600', // 10 min after the last player leaves
    'AUTOSTOP_TIMEOUT_INIT=900', // 15 min if nobody joins after start
    'MODRINTH_PROJECTS=viaversion?,viabackwards?', // other game versions can join
  ].join('\n');
}
// Old 1.x versions need Java 21; new 26.x versions need the newest Java.
const imageFor = (version) =>
  /^1\./.test(version) ? 'itzg/minecraft-server:java21' : 'itzg/minecraft-server:latest';

async function createVm(id, config) {
  const [resp] = await instances.insert({
    project: PROJECT,
    zone: ZONE,
    instanceResource: {
      name: vmName(id),
      machineType: `zones/${ZONE}/machineTypes/${MACHINE}`,
      labels: { mc_server: 'true', server_id: id },
      tags: { items: ['mc-server'] }, // the firewall opens port 25565 for this tag
      disks: [{
        boot: true,
        autoDelete: true, // disk goes away with the VM, so no idle disk bill
        initializeParams: {
          sourceImage: 'projects/debian-cloud/global/images/family/debian-12',
          diskSizeGb: 20,
          diskType: `zones/${ZONE}/diskTypes/pd-balanced`,
        },
      }],
      networkInterfaces: [{
        network: 'global/networks/default',
        accessConfigs: [{ name: 'External NAT', type: 'ONE_TO_ONE_NAT', networkTier: 'STANDARD' }],
      }],
      serviceAccounts: [{ email: VM_SA, scopes: ['https://www.googleapis.com/auth/cloud-platform'] }],
      metadata: {
        items: [
          { key: 'startup-script', value: STARTUP },
          { key: 'server-id', value: id },
          { key: 'backup-bucket', value: BUCKET },
          { key: 'mc-env', value: envFile(config) },
          { key: 'mc-image', value: imageFor(config.version) },
          { key: 'mc-stop', value: 'false' },
        ],
      },
    },
  });
  await waitOp(resp);
}

async function getVm(name) {
  try {
    const [vm] = await instances.get({ project: PROJECT, zone: ZONE, instance: name });
    return vm;
  } catch (e) {
    if (isNotFound(e)) return null;
    throw e;
  }
}

// All game VMs in the zone, keyed by VM name.
async function listGameVms() {
  const [vms] = await instances.list({ project: PROJECT, zone: ZONE });
  return new Map(vms.filter((vm) => vm.labels && vm.labels.mc_server === 'true').map((vm) => [vm.name, vm]));
}

const vmIp = (vm) => vm?.networkInterfaces?.[0]?.accessConfigs?.[0]?.natIP || null;
const vmStartedAt = (vm) => Date.parse(vm.lastStartTimestamp || vm.creationTimestamp);

// Flip the VM's mc-stop flag; the VM's watcher then saves, backs up and powers off.
async function requestStop(name) {
  const vm = await getVm(name);
  if (!vm) throw Object.assign(new Error('The VM is not ready yet, try again in a moment'), { status: 409 });
  const items = (vm.metadata.items || []).filter((i) => i.key !== 'mc-stop');
  items.push({ key: 'mc-stop', value: 'true' });
  const [resp] = await instances.setMetadata({
    project: PROJECT,
    zone: ZONE,
    instance: name,
    metadataResource: { fingerprint: vm.metadata.fingerprint, items },
  });
  await waitOp(resp);
}

async function deleteVm(name) {
  try {
    const [resp] = await instances.delete({ project: PROJECT, zone: ZONE, instance: name });
    await waitOp(resp);
  } catch (e) {
    if (!isNotFound(e)) throw e; // already gone is fine
  }
}

// Time (ms) of the latest world backup for a server, or 0 if there is none.
async function backupTime(id) {
  try {
    const [meta] = await bucket.file(`${id}/world.tgz`).getMetadata();
    return Date.parse(meta.updated);
  } catch (e) {
    if (isNotFound(e)) return 0;
    throw e;
  }
}

async function deleteBackups(id) {
  await bucket.deleteFiles({ prefix: `${id}/`, versions: true });
}

module.exports = {
  vmName, createVm, getVm, listGameVms, vmIp, vmStartedAt,
  requestStop, deleteVm, backupTime, deleteBackups,
};
