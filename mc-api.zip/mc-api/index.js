// Minecraft servers on demand - backend API (Phase 3).
// Runs on Cloud Run as the mc-api service account.
//
// Firestore holds all the state:
//   servers/{id}   one doc per server: owner, name, status, settings, IP
//   names/{name}   reserves each server name (it becomes the subdomain later)
//   meta/slots     { active: {serverId: uid}, queue: [{id, uid, at}] }
//                  -> the "max 5 running" limit and the waiting queue
// Every change to meta/slots happens inside a transaction, so two clicks at the
// same moment can never start a 6th server or the same server twice.
const path = require('path');
const express = require('express');
const crypto = require('crypto');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getAuth } = require('firebase-admin/auth');
const { OAuth2Client } = require('google-auth-library');
const mcu = require('minecraft-server-util');
const gcp = require('./gcp');

const { PROJECT } = process.env;
const AUTH_MODE = process.env.AUTH_MODE || 'firebase'; // 'test' only while the service is private (Phase 3)
const MAX_ACTIVE = Number(process.env.MAX_ACTIVE || 5); // servers running at once, across all users
const MAX_SERVERS_PER_USER = 2;
const SCHEDULER_SA = `mc-scheduler@${PROJECT}.iam.gserviceaccount.com`;
const ACTIVE = ['starting', 'online', 'stopping'];

initializeApp({ projectId: PROJECT });
const db = getFirestore();
const slotsRef = db.doc('meta/slots');
const serverRef = (id) => db.doc(`servers/${id}`);
const oidc = new OAuth2Client();

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const slotsOf = (snap) => ({ active: {}, queue: [], ...(snap.exists ? snap.data() : {}) });

const app = express();
app.use(express.json());
app.use((req, res, next) => { // basic safety headers for the website
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'DENY' });
  next();
});
app.use(express.static(path.join(__dirname, 'public'))); // the dashboard website

// ---------------------------------------------------------------- login check
// firebase mode (Phase 4+): the browser sends the Firebase ID token; we verify it.
// test mode (Phase 3): Cloud Run itself only lets the project owner in, and the
//   X-Test-User header just picks which pretend user you are.
async function auth(req, res, next) {
  try {
    if (AUTH_MODE === 'test') {
      const who = String(req.get('X-Test-User') || 'me').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20);
      req.uid = `test-${who || 'me'}`;
    } else {
      const token = (req.get('Authorization') || '').replace(/^Bearer /, '');
      const user = await getAuth().verifyIdToken(token); // checks Google's signature + expiry
      req.uid = user.uid;
      req.email = user.email || null;
    }
    next();
  } catch {
    res.status(401).json({ error: 'Please log in' });
  }
}

// Only the owner may see or control a server. Strangers get 404, not "forbidden",
// so they can't even tell the server exists.
async function ownServer(req) {
  if (!/^[0-9a-f]{8}$/.test(req.params.id)) throw new HttpError(404, 'Server not found');
  const snap = await serverRef(req.params.id).get();
  if (!snap.exists || snap.data().ownerUid !== req.uid) throw new HttpError(404, 'Server not found');
  return snap.data();
}

function view(id, s, slots) {
  const out = {
    id,
    name: s.name,
    status: s.status,
    address: s.ip || null,
    players: s.players || null,
    version: s.config.version,
    onlineMode: s.config.onlineMode,
    lastBackupAt: s.lastBackupAt ? s.lastBackupAt.toDate().toISOString() : null,
  };
  if (s.error) out.error = s.error;
  if (s.status === 'queued' && slots) out.queuePosition = slots.queue.findIndex((q) => q.id === id) + 1;
  return out;
}

// Look at the real VM and ping Minecraft, then update the doc (starting -> online, IP, players).
async function refresh(id, s) {
  if (!ACTIVE.includes(s.status)) return s;
  const vm = await gcp.getVm(s.vmName);
  const upd = {};
  if (vm && vm.status === 'RUNNING') {
    const ip = gcp.vmIp(vm);
    if (ip && ip !== s.ip) upd.ip = ip;
    if (ip && s.status !== 'stopping') {
      try {
        const r = await mcu.status(ip, 25565, { timeout: 2000, enableSRV: false });
        upd.status = 'online';
        upd.players = { online: r.players.online, max: r.players.max };
      } catch { /* Minecraft not answering yet */ }
    }
  } else if (vm && vm.status === 'TERMINATED' && s.status !== 'stopping') {
    upd.status = 'stopping'; // it powered itself off; reconcile will finish the job
  }
  if (!Object.keys(upd).length) return s;
  // only write if nobody (e.g. reconcile) changed the status in the meantime
  await db.runTransaction(async (tx) => {
    const cur = await tx.get(serverRef(id));
    if (cur.exists && cur.data().status === s.status) tx.update(serverRef(id), upd);
  });
  return { ...s, ...upd };
}

// Give a server's slot back (and drop it from the queue), optionally updating its doc.
async function freeSlot(id, updates) {
  await db.runTransaction(async (tx) => {
    const [slotsSnap, snap] = await tx.getAll(slotsRef, serverRef(id));
    const slots = slotsOf(slotsSnap);
    delete slots.active[id];
    slots.queue = slots.queue.filter((q) => q.id !== id);
    tx.set(slotsRef, slots);
    if (updates && snap.exists) tx.update(serverRef(id), updates);
  });
}

// Create the VM for a server that already holds a slot. On failure the slot is given back.
async function launch(id) {
  const s = (await serverRef(id).get()).data();
  try {
    await gcp.createVm(id, s.config);
    return null;
  } catch (e) {
    console.error(`createVm ${id} failed:`, e);
    const error = `Could not create the VM: ${e.message}`;
    await freeSlot(id, { status: 'error', error });
    return error;
  }
}

// ---------------------------------------------------------------- routes
app.get('/healthz', (req, res) => res.json({ service: 'mc-api', ok: true }));

// How busy the platform is: shown on the dashboard.
app.get('/capacity', auth, async (req, res) => {
  const slots = slotsOf(await slotsRef.get());
  res.json({ running: Object.keys(slots.active).length, max: MAX_ACTIVE, waiting: slots.queue.length });
});

// Create a server: only writes Firestore. No VM until the first Start, so it costs nothing.
app.post('/servers', auth, async (req, res) => {
  const name = String(req.body?.name || '').toLowerCase();
  if (!/^[a-z][a-z0-9-]{1,18}[a-z0-9]$/.test(name)) {
    throw new HttpError(400, 'Name must be 3-20 characters: lowercase letters, digits and hyphens, starting with a letter');
  }
  const version = String(req.body?.version || '1.21.4');
  if (!/^(LATEST|\d{1,2}\.\d{1,2}(\.\d{1,2})?)$/.test(version)) throw new HttpError(400, 'Version looks like 1.21.4 or 26.3');
  const onlineMode = req.body?.onlineMode === true; // default: cracked launchers allowed
  const id = crypto.randomBytes(4).toString('hex'); // VM will be mc-<id>

  await db.runTransaction(async (tx) => {
    const mine = await tx.get(db.collection('servers').where('ownerUid', '==', req.uid));
    if (mine.size >= MAX_SERVERS_PER_USER) throw new HttpError(403, `You can have at most ${MAX_SERVERS_PER_USER} servers`);
    const nameRef = db.doc(`names/${name}`);
    if ((await tx.get(nameRef)).exists) throw new HttpError(409, 'That name is already taken');
    tx.create(nameRef, { serverId: id });
    tx.create(serverRef(id), {
      ownerUid: req.uid,
      ownerEmail: req.email || null,
      name,
      status: 'offline', // offline | queued | starting | online | stopping | error
      vmName: gcp.vmName(id),
      ip: null,
      players: null,
      startedAt: null,
      lastBackupAt: null,
      config: { version, onlineMode },
      createdAt: FieldValue.serverTimestamp(),
    });
  });
  res.status(201).json({ id, name, status: 'offline', version, onlineMode });
});

// List my servers (with live status).
app.get('/servers', auth, async (req, res) => {
  const [snap, slotsSnap] = await Promise.all([
    db.collection('servers').where('ownerUid', '==', req.uid).get(),
    slotsRef.get(),
  ]);
  const slots = slotsOf(slotsSnap);
  const list = await Promise.all(snap.docs.map(async (d) => view(d.id, await refresh(d.id, d.data()), slots)));
  res.json(list);
});

// One server, with live status: VM state, IP, players online, queue position.
app.get('/servers/:id', auth, async (req, res) => {
  const s = await refresh(req.params.id, await ownServer(req));
  res.json(view(req.params.id, s, slotsOf(await slotsRef.get())));
});

// Start: take a free slot and create the VM, or join the queue if all slots are busy.
app.post('/servers/:id/start', auth, async (req, res) => {
  const id = req.params.id;
  await ownServer(req);
  const result = await db.runTransaction(async (tx) => {
    const [slotsSnap, snap] = await tx.getAll(slotsRef, serverRef(id));
    if (!snap.exists) throw new HttpError(404, 'Server not found');
    const s = snap.data();
    if (s.status !== 'offline') throw new HttpError(409, `Server is ${s.status}`);
    const slots = slotsOf(slotsSnap);
    const busy = Object.values(slots.active).includes(req.uid) || slots.queue.some((q) => q.uid === req.uid);
    if (busy) throw new HttpError(409, 'You already have a server running or waiting in the queue');
    if (Object.keys(slots.active).length < MAX_ACTIVE) {
      slots.active[id] = req.uid;
      tx.set(slotsRef, slots);
      tx.update(serverRef(id), { status: 'starting', startedAt: FieldValue.serverTimestamp(), ip: null, players: null, error: FieldValue.delete() });
      return { status: 'starting' };
    }
    slots.queue.push({ id, uid: req.uid, at: Date.now() });
    tx.set(slotsRef, slots);
    tx.update(serverRef(id), { status: 'queued', error: FieldValue.delete() });
    return { status: 'queued', queuePosition: slots.queue.length };
  });
  if (result.status === 'starting') {
    const error = await launch(id);
    if (error) throw new HttpError(500, error);
  }
  res.status(202).json(result);
});

// Stop: leave the queue, or ask the VM to save, back up and power off.
app.post('/servers/:id/stop', auth, async (req, res) => {
  const id = req.params.id;
  const s = await ownServer(req);
  if (s.status === 'queued') {
    await freeSlot(id, { status: 'offline' });
    return res.json({ status: 'offline' });
  }
  if (!['starting', 'online'].includes(s.status)) throw new HttpError(409, `Server is ${s.status}`);
  await gcp.requestStop(s.vmName);
  await serverRef(id).update({ status: 'stopping' });
  res.status(202).json({ status: 'stopping' });
});

// Delete a server for good: VM, all world backups, and the name.
app.delete('/servers/:id', auth, async (req, res) => {
  const id = req.params.id;
  const s = await ownServer(req);
  if (!['offline', 'error'].includes(s.status)) throw new HttpError(409, 'Stop the server before deleting it');
  await gcp.deleteVm(s.vmName);
  await gcp.deleteBackups(id);
  await freeSlot(id);
  const batch = db.batch();
  batch.delete(serverRef(id));
  batch.delete(db.doc(`names/${s.name}`));
  await batch.commit();
  res.status(204).end();
});

// ---------------------------------------------------------------- reconcile
// Cloud Scheduler calls this every 2 minutes. It:
//  1. deletes powered-off VMs whose backup is newer than their start, frees their slot
//     (no fresh backup -> VM kept, server marked "error", nothing is lost)
//  2. does the same for game VMs no server doc knows about (e.g. made by mc.sh)
//  3. starts the oldest queued servers if slots are free
async function reconcile() {
  const log = [];
  const vms = await gcp.listGameVms();
  const slots = slotsOf(await slotsRef.get());

  for (const id of Object.keys(slots.active)) {
    const snap = await serverRef(id).get();
    if (!snap.exists) { await freeSlot(id); log.push(`${id}: server was deleted, slot freed`); continue; }
    const s = snap.data();
    const vm = vms.get(s.vmName);
    if (!vm) {
      const age = Date.now() - (s.startedAt ? s.startedAt.toMillis() : 0);
      if (s.status === 'starting' && age < 5 * 60e3) continue; // VM still being created
      await freeSlot(id, { status: 'offline', ip: null, players: null });
      log.push(`${id}: VM is gone, marked offline`);
      continue;
    }
    if (vm.status !== 'TERMINATED') continue; // still running or shutting down
    const backupAt = await gcp.backupTime(id);
    if (backupAt > gcp.vmStartedAt(vm)) {
      await gcp.deleteVm(vm.name);
      await freeSlot(id, { status: 'offline', ip: null, players: null, lastBackupAt: new Date(backupAt) });
      log.push(`${id}: backed up, VM deleted, offline`);
    } else {
      await freeSlot(id, {
        status: 'error', ip: null, players: null,
        error: 'The server stopped without a fresh backup. Its VM was kept so nothing is lost.',
      });
      log.push(`${id}: NO fresh backup - VM kept, marked error`);
    }
  }

  for (const vm of vms.values()) {
    const id = vm.labels.server_id;
    if (vm.status !== 'TERMINATED' || !id || slots.active[id]) continue;
    if ((await serverRef(id).get()).exists) continue; // tracked server, handled above
    if ((await gcp.backupTime(id)) > gcp.vmStartedAt(vm)) {
      await gcp.deleteVm(vm.name);
      log.push(`${vm.name}: untracked VM, backed up, deleted`);
    }
  }

  const promoted = await db.runTransaction(async (tx) => {
    const cur = slotsOf(await tx.get(slotsRef));
    const free = MAX_ACTIVE - Object.keys(cur.active).length;
    if (free <= 0 || cur.queue.length === 0) return [];
    const picks = cur.queue.slice(0, free);
    const snaps = await tx.getAll(...picks.map((q) => serverRef(q.id)));
    cur.queue = cur.queue.slice(picks.length);
    const started = [];
    picks.forEach((q, i) => {
      if (!snaps[i].exists || snaps[i].data().status !== 'queued') return; // left the queue meanwhile
      cur.active[q.id] = q.uid;
      tx.update(serverRef(q.id), { status: 'starting', startedAt: FieldValue.serverTimestamp(), ip: null, players: null });
      started.push(q.id);
    });
    tx.set(slotsRef, cur);
    return started;
  });
  for (const id of promoted) {
    const error = await launch(id);
    log.push(error ? `${id}: promoted from the queue, but ${error}` : `${id}: promoted from the queue, starting`);
  }
  return log.length ? log : ['nothing to do'];
}

// When the service is public (Phase 4), only Cloud Scheduler's signed token may call this.
async function checkScheduler(req) {
  try {
    const token = (req.get('Authorization') || '').replace(/^Bearer /, '');
    const ticket = await oidc.verifyIdToken({ idToken: token, audience: `https://${req.get('host')}` });
    if (ticket.getPayload().email !== SCHEDULER_SA) throw new Error('wrong caller');
  } catch {
    throw new HttpError(403, 'Forbidden');
  }
}

app.post('/internal/reconcile', async (req, res) => {
  if (AUTH_MODE !== 'test') await checkScheduler(req);
  const log = await reconcile();
  console.log('reconcile:', log.join(' | '));
  res.json({ log });
});

// ---------------------------------------------------------------- errors + start
app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: err.message || 'Something went wrong' });
});

const PORT = Number(process.env.PORT || 8080);
const server = app.listen(PORT, () =>
  console.log(`mc-api listening on ${PORT} (auth=${AUTH_MODE}, max running servers=${MAX_ACTIVE})`));

module.exports = { app, server, reconcile };
