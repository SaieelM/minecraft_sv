#!/bin/bash
# Deploy the website + API to Cloud Run.
# Run in Cloud Shell from inside this folder:   bash setup.sh
# Run it again whenever you change the code - it just redeploys.
#
#   bash setup.sh                    Phase 4: public website with Google sign-in (Firebase)
#   AUTH_MODE=test bash setup.sh     Phase 3: private API, pretend users via api.sh
#   MAX_ACTIVE=1 bash setup.sh       only 1 server may run at once (cheap way to test the queue)
set -euo pipefail
cd "$(dirname "$0")"

REGION=asia-south1
ZONE=asia-south1-a
MAX_ACTIVE=${MAX_ACTIVE:-5}       # servers allowed to run at the same time
AUTH_MODE=${AUTH_MODE:-firebase}  # firebase = real Google sign-in, site is public

PROJECT=$(gcloud config get-value project 2>/dev/null || true)
if [ -z "$PROJECT" ]; then
  echo "No project set. Run: gcloud config set project YOUR_PROJECT_ID"; exit 1
fi
BUCKET=mc-backups-$PROJECT
API_SA=mc-api@$PROJECT.iam.gserviceaccount.com
VM_SA=mc-game-vm@$PROJECT.iam.gserviceaccount.com
SCHED_SA=mc-scheduler@$PROJECT.iam.gserviceaccount.com

retry() {  # new service accounts take a few seconds to become usable
  local i; for i in 1 2 3 4 5 6; do "$@" && return 0; echo "  (retrying in 10s...)"; sleep 10; done
  return 1
}
# Call a Google REST API as you (for Firebase settings that gcloud has no command for)
gapi() {
  curl -sS -H "Authorization: Bearer $(gcloud auth print-access-token)" \
    -H "x-goog-user-project: $PROJECT" -H "Content-Type: application/json" "$@"
}

if ! gcloud storage buckets describe "gs://$BUCKET" >/dev/null 2>&1; then
  echo "Do Phase 2 first:  bash mc.sh setup"; exit 1
fi

echo "== Enabling APIs =="
gcloud services enable firestore.googleapis.com run.googleapis.com cloudbuild.googleapis.com \
  artifactregistry.googleapis.com cloudscheduler.googleapis.com
if [ "$AUTH_MODE" = firebase ]; then
  gcloud services enable firebase.googleapis.com identitytoolkit.googleapis.com firebaserules.googleapis.com
fi

# ------------------------------------------------------------ Firebase (Phase 4)
if [ "$AUTH_MODE" = firebase ]; then
  echo "== Reading your Firebase web app settings =="
  if ! gapi -f "https://firebase.googleapis.com/v1beta1/projects/$PROJECT" >/dev/null 2>&1; then
    echo "Firebase isn't added to this project yet."
    echo "Do steps 1-3 in the Firebase console first (see README.md), then run this again."
    exit 1
  fi
  APP_ID=$(gapi "https://firebase.googleapis.com/v1beta1/projects/$PROJECT/webApps" | jq -r '.apps[0].appId // empty')
  if [ -z "$APP_ID" ]; then
    echo "No web app is registered in Firebase yet."
    echo "Firebase console > Project settings > Your apps > Add app > Web (</>), then run this again."
    exit 1
  fi
  CONFIG=$(gapi "https://firebase.googleapis.com/v1beta1/projects/$PROJECT/webApps/$APP_ID/config" \
    | jq '{apiKey, authDomain, projectId, appId, messagingSenderId}')
  if [ "$(echo "$CONFIG" | jq -r '.apiKey // empty')" = "" ]; then
    echo "Could not read the web app config. Paste it into public/firebase-config.js by hand"
    echo "(Firebase console > Project settings > Your apps > SDK setup and configuration > Config)."
    exit 1
  fi
  {
    echo "// Written by setup.sh from your Firebase web app. These values are public by design:"
    echo "// they only identify the project. Security comes from the API checking every token."
    printf 'export const firebaseConfig = %s;\n' "$CONFIG"
  } > public/firebase-config.js
  echo "   Saved public/firebase-config.js (web app $APP_ID)"

  echo "== Locking Firestore so browsers can't touch it directly (only the API can) =="
  RULESET=$(jq -n --rawfile c firestore.rules '{source:{files:[{name:"firestore.rules",content:$c}]}}' \
    | gapi -X POST "https://firebaserules.googleapis.com/v1/projects/$PROJECT/rulesets" -d @- | jq -r '.name // empty')
  if [ -n "$RULESET" ]; then
    REL="projects/$PROJECT/releases/cloud.firestore"
    if gapi -f -X PATCH "https://firebaserules.googleapis.com/v1/$REL" \
         -d "$(jq -n --arg n "$REL" --arg r "$RULESET" '{release:{name:$n,rulesetName:$r}}')" >/dev/null 2>&1 || \
       gapi -f -X POST "https://firebaserules.googleapis.com/v1/projects/$PROJECT/releases" \
         -d "$(jq -n --arg n "$REL" --arg r "$RULESET" '{name:$n,rulesetName:$r}')" >/dev/null 2>&1; then
      echo "   Rules published."
    else
      echo "   WARNING: could not publish rules. Paste firestore.rules into Firebase console > Firestore > Rules."
    fi
  else
    echo "   WARNING: could not create rules. Paste firestore.rules into Firebase console > Firestore > Rules."
  fi
fi

# ------------------------------------------------------------ database + service account
echo "== Firestore database (Native mode, Mumbai) =="
gcloud firestore databases describe --database='(default)' >/dev/null 2>&1 || \
  gcloud firestore databases create --location=$REGION --type=firestore-native

echo "== mc-api service account: manage VMs, use Firestore, read/delete backups =="
if ! gcloud iam service-accounts describe "$API_SA" >/dev/null 2>&1; then
  gcloud iam service-accounts create mc-api --display-name="Minecraft API"
  sleep 10
fi
retry gcloud projects add-iam-policy-binding "$PROJECT" --condition=None \
  --member="serviceAccount:$API_SA" --role=roles/compute.instanceAdmin.v1 >/dev/null
retry gcloud projects add-iam-policy-binding "$PROJECT" --condition=None \
  --member="serviceAccount:$API_SA" --role=roles/datastore.user >/dev/null
retry gcloud iam service-accounts add-iam-policy-binding "$VM_SA" \
  --member="serviceAccount:$API_SA" --role=roles/iam.serviceAccountUser >/dev/null
retry gcloud storage buckets add-iam-policy-binding "gs://$BUCKET" \
  --member="serviceAccount:$API_SA" --role=roles/storage.objectAdmin >/dev/null

# ------------------------------------------------------------ deploy
if [ "$AUTH_MODE" = firebase ]; then
  # Public website. --no-invoker-iam-check works even where the organisation
  # blocks "allUsers" (common on college / company Google accounts).
  ACCESS=(--no-invoker-iam-check)
  echo "== Deploying the website + API to Cloud Run (public, Google sign-in) =="
else
  ACCESS=(--no-allow-unauthenticated --invoker-iam-check)
  echo "== Deploying the API to Cloud Run (private test mode) =="
fi
gcloud run deploy mc-api --source . --region=$REGION --service-account="$API_SA" \
  "${ACCESS[@]}" --memory=1Gi --cpu=1 --timeout=300 --min-instances=0 --max-instances=3 \
  --set-env-vars="PROJECT=$PROJECT,ZONE=$ZONE,BUCKET=$BUCKET,AUTH_MODE=$AUTH_MODE,MAX_ACTIVE=$MAX_ACTIVE" \
  --quiet
URL=$(gcloud run services describe mc-api --region=$REGION --format='value(status.url)')

if [ "$AUTH_MODE" = firebase ]; then
  echo "== Allowing Google sign-in on ${URL#https://} =="
  HOST=${URL#https://}
  AUTHCFG=$(gapi "https://identitytoolkit.googleapis.com/admin/v2/projects/$PROJECT/config")
  if echo "$AUTHCFG" | jq -e --arg h "$HOST" '(.authorizedDomains // []) | index($h)' >/dev/null; then
    echo "   Already allowed."
  elif gapi -f -X PATCH "https://identitytoolkit.googleapis.com/admin/v2/projects/$PROJECT/config?updateMask=authorizedDomains" \
         -d "$(echo "$AUTHCFG" | jq -c --arg h "$HOST" '{authorizedDomains: ((.authorizedDomains // []) + [$h])}')" >/dev/null 2>&1; then
    echo "   Added."
  else
    echo "   WARNING: add $HOST by hand: Firebase console > Authentication > Settings > Authorized domains."
  fi
fi

# ------------------------------------------------------------ scheduler
echo "== Scheduler: call /internal/reconcile every 2 minutes =="
retry gcloud run services add-iam-policy-binding mc-api --region=$REGION \
  --member="serviceAccount:$SCHED_SA" --role=roles/run.invoker >/dev/null
verb=create
gcloud scheduler jobs describe mc-reconcile --location=$REGION >/dev/null 2>&1 && verb=update
gcloud scheduler jobs $verb http mc-reconcile --location=$REGION --schedule="*/2 * * * *" \
  --uri="$URL/internal/reconcile" --http-method=POST \
  --oidc-service-account-email="$SCHED_SA" --oidc-token-audience="$URL"

# the Phase 2 cleanup function is no longer needed (reconcile does its job, for mc.sh VMs too)
gcloud scheduler jobs delete mc-cleanup --location=$REGION --quiet 2>/dev/null || true
gcloud functions delete mc-cleanup --gen2 --region=$REGION --quiet 2>/dev/null || true

echo
if [ "$AUTH_MODE" = firebase ]; then
  echo "Done. Open your website:  $URL"
else
  echo "Done. Private test API: $URL   Try:  bash api.sh create steve"
fi
echo "Max servers running at once: $MAX_ACTIVE"
