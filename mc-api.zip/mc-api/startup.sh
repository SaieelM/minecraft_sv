#!/bin/bash
# Runs as root on EVERY boot of a game VM. The API puts everything this script
# needs in the VM's metadata, so the VM never touches the database.
MD=http://metadata.google.internal/computeMetadata/v1/instance/attributes
H="Metadata-Flavor: Google"
ID=$(curl -s -H "$H" $MD/server-id)
BUCKET=$(curl -s -H "$H" $MD/backup-bucket)
IMAGE=$(curl -s -H "$H" $MD/mc-image)
BACKUP="gs://$BUCKET/$ID/world.tgz"
stop_requested() { [ "$(curl -s -H "$H" "$MD/mc-stop$1")" = "true" ]; }

# 1. Settings chosen on the website (version, cracked mode...) as Docker env vars
curl -s -H "$H" $MD/mc-env -o /etc/mc.env

# 2. Docker (first boot only)
if ! command -v docker >/dev/null; then
  apt-get update
  apt-get -o DPkg::Lock::Timeout=300 install -y docker.io
fi

# 3. Restore the world, but only onto an empty disk (never overwrite newer local data)
mkdir -p /mc-data
if [ -z "$(ls -A /mc-data)" ]; then
  if gcloud storage cp "$BACKUP" /tmp/world.tgz 2>/dev/null; then
    tar -xzf /tmp/world.tgz -C /mc-data && rm -f /tmp/world.tgz
    echo "Restored world from $BACKUP"
  else
    echo "No backup at $BACKUP yet - starting a new world"
  fi
fi

# 4. Watch for the Stop button (the API sets metadata mc-stop=true). Waits without polling.
( until stop_requested "" || stop_requested "?wait_for_change=true&timeout_sec=300"; do sleep 1; done
  echo "Stop requested - saving world"
  until docker stop -t 60 mc 2>/dev/null; do sleep 5; done ) &

# 5. Run Minecraft. Blocks while people play; returns on autostop (10 empty min) or Stop.
START=$(date +%s)
docker rm -f mc 2>/dev/null
docker run --rm --name mc --stop-timeout 60 -v /mc-data:/data -p 25565:25565 \
  --env-file /etc/mc.env "$IMAGE"

# 6. Crashed right after starting (and nobody pressed Stop)? Stay on so logs can be read.
if [ $(( $(date +%s) - START )) -lt 300 ] && ! stop_requested ""; then
  echo "Minecraft exited early - NOT backing up. Check the logs above."; exit 1
fi

# 7. Back up, and power off ONLY if the upload worked. The API's reconcile job
#    then checks the backup is fresh and deletes this VM.
echo "Backing up world to $BACKUP"
if tar -czf /tmp/world.tgz -C /mc-data . && gcloud storage cp /tmp/world.tgz "$BACKUP"; then
  echo "Backup OK - powering off"; poweroff
else
  echo "BACKUP FAILED - staying on so the world is not lost"
fi
